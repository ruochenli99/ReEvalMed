import json
import pandas as pd
from radfact.data_utils.grounded_phrase_list import GroundedPhraseList
from radfact.metric.radfact import RadFactMetric
from radfact.metric.bootstrapping import MetricBootstrapper
from radfact.metric.print_utils import print_bootstrap_results, print_results
from radfact.paths import EXAMPLES_DIR

findings_generation_examples = pd.read_csv(EXAMPLES_DIR / 'findings_generation_examples.csv')
# display(findings_generation_examples.head(2))
candidates_fg = findings_generation_examples.set_index("example_id")["prediction"].to_dict()
references_fg = findings_generation_examples.set_index("example_id")["target"].to_dict()

print(candidates_fg)
print(references_fg)

radfact_metric_for_fg = RadFactMetric(is_narrative_text=True)

results_per_sample_fg = radfact_metric_for_fg.compute_results_per_sample(candidates_fg, references_fg)
print(results_per_sample_fg)
logical_f1_fg, radfact_scores_fg = radfact_metric_for_fg.aggregate_results(results_per_sample_fg)
print(logical_f1_fg)

print("Findings generation RadFact scores:")
print_results(radfact_scores_fg, metrics=["logical_precision", "logical_recall", "logical_f1"])

bootstrapper = MetricBootstrapper(metric=radfact_metric_for_fg, num_samples=10, seed=42)
radfact_scores_fg_with_cis = bootstrapper.compute_bootstrap_metrics(results_per_sample=results_per_sample_fg)

print("Findings generation RadFact scores (95% CI):")
print_bootstrap_results(radfact_scores_fg_with_cis, metrics=["logical_precision", "logical_recall", "logical_f1"])
