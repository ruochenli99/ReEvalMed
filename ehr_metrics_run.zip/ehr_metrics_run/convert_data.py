#!/usr/bin/env python
# excel_to_json.py
"""
Convert the custom-formatted Excel sheet produced by the radiology-
comparison pipeline into the JSON schema

[
  {
    "significance": <int>,
    "data": [
      {
        "GT": "...",
        "ME": "...",
        "type": "<column-header>",
        "error_type": "<code from header row>"
      },
      ...
    ]
  },
  ...
]
"""

import json
import pathlib
import sys
import pandas as pd


def excel_to_json(path: str | pathlib.Path) -> list[dict]:
    """
    Convert the Excel file at *path* to the required JSON structure.

    If a column’s header is an “Unnamed” placeholder, the column inherits the
    nearest non-Unnamed header that appears to its left. (It may need to step
    leftward more than one column.)
    """
    import json
    import pandas as pd

    df = pd.read_excel(path)

    # Row 0 holds the per-column error-type codes (O / F / …)
    error_type_row = df.iloc[0]

    # -- 1. Build a lookup that maps every column index ➜ effective header ----
    effective_headers: dict[int, str] = {}
    last_named = None
    for idx, col in enumerate(df.columns):
        if isinstance(col, str) and not col.lower().startswith("unnamed"):
            last_named = col.strip()
        effective_headers[idx] = last_named if last_named is not None else str(col)

    # -- 2. Walk the sheet two rows at a time (GT row then ME row) -------------
    result: list[dict] = []
    i = 1  # start after the error-type row
    while i < len(df):
        gt_row = df.iloc[i]
        if gt_row.get("pair") != "GT":
            i += 1
            continue  # safety net

        if i + 1 >= len(df) or df.iloc[i + 1].get("pair") != "ME":
            raise ValueError(f"Expected ME row after GT row at index {i}")
        me_row = df.iloc[i + 1]

        sig_val = gt_row["significance"]
        significance = int(sig_val) if pd.notna(sig_val) else None

        data_block: list[dict] = []
        for idx, col in enumerate(df.columns[2:], start=2):  # skip 'pair' & 'significance'
            gt_val, me_val = gt_row[col], me_row[col]
            if pd.isna(gt_val) and pd.isna(me_val):
                continue  # nothing to record

            type_name = effective_headers[idx]

            entry = {
                "GT": "" if pd.isna(gt_val) else str(gt_val).strip(),
                "ME": "" if pd.isna(me_val) else str(me_val).strip(),
                "type": type_name,
                "error_type": (
                    "" if pd.isna(error_type_row[col]) else str(error_type_row[col]).strip()
                ),
            }
            data_block.append(entry)

        result.append({"significance": significance, "data": data_block})
        i += 2  # advance to the next GT/ME pair

    return result


if __name__ == "__main__":

    excel_path = "data.xlsx"
    output_path = excel_path.replace(".xlsx", ".json")

    json_data = excel_to_json(excel_path)
    with open(output_path, "w", encoding="utf-8") as fp:
        json.dump(json_data, fp, indent=2, ensure_ascii=False)

    print(f"✔ Done! JSON saved to {output_path}")