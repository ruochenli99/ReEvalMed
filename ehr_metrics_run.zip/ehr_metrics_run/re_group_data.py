import json
import os

data_path = "data/rate_check.json"

with open(data_path) as f:
    all_data = json.load(f)

for idx in range(len(all_data)):
    for item_idx in range(len(all_data[idx]["data"])):
        if "score" in all_data[idx]["data"][item_idx]:
            del all_data[idx]["data"][item_idx]["score"]


correctness_data = []
robustness_data = []

error_level_data = [{"error_level": x, "data": []} for x in range(0, 5)]

for item in all_data:
    if 0 <= item["significance"] <= 9:
        robustness_data.extend(item["data"])
    elif 10 <= item["significance"] <= 19:
        correctness_data.extend(item["data"])
    idx = item["significance"] // 4
    error_level_data[idx]["data"].extend(item["data"])


correctness_data = [x for x in correctness_data if x["type"] != "Calibration"]
robustness_data = [x for x in robustness_data if x["type"] != "Calibration"]

for i in range(len(error_level_data)):
    error_level_data[i]["data"] = [x for x in error_level_data[i]["data"] if x["type"] == "Calibration"]

save_dir = "data"
os.makedirs(save_dir, exist_ok=True)

with open(os.path.join(save_dir, "correctness_data.json"), "w") as f:
    json.dump(correctness_data, f, indent=4)
with open(os.path.join(save_dir, "robustness_data.json"), "w") as f:
    json.dump(robustness_data, f, indent=4)
with open(os.path.join(save_dir, "error_level_data.json"), "w") as f:
    json.dump(error_level_data, f, indent=4)

