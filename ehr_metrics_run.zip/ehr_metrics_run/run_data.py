import json
import os
from tqdm import tqdm

save_dir = "results"


def load_data(data_path):
    with open(data_path) as f:
        data = json.load(f)

    return data


def run_list(data_list, cal_metrics_fun, save_name):
    for idx, sample in tqdm(enumerate(data_list), total=len(data_list), desc="Processing list"):
        score = cal_metrics_fun(sample["GT"], sample["ME"])
        sample["score"] = score
        print("score:", score)
        data_list[idx] = sample

    save_path = os.path.join(save_dir, f"{save_name}.json")
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    with open(save_path, "w") as f:
        json.dump(data_list, f, indent=4)


def run_level(data_level_list, cal_metrics_fun, save_name):
    for idx, single_level_list in enumerate(data_level_list):
        for sample_idx, sample in tqdm(enumerate(single_level_list["data"]), total=len(single_level_list["data"]), desc=f"Level {idx}"):
            score = cal_metrics_fun(sample["GT"], sample["ME"])
            sample["score"] = score
            data_level_list[idx]["data"][sample_idx] = sample

    save_path = os.path.join(save_dir, f"{save_name}.json")
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    with open(save_path, "w") as f:
        json.dump(data_level_list, f, indent=4)


def run_all(met_fun, save_name):
    correctness_data_path = "data/correctness_data.json"
    robustness_data_path = "data/robustness_data.json"
    error_level_data_path = "data/error_level_data.json"

    with open(correctness_data_path) as f:
        correctness_data = json.load(f)
    with open(robustness_data_path) as f:
        robustness_data = json.load(f)
    with open(error_level_data_path) as f:
        error_level_data = json.load(f)

    run_list(correctness_data, met_fun, f"{save_name}/correctness")
    run_list(robustness_data, met_fun, f"{save_name}/robustness")
    run_level(error_level_data, met_fun, f"{save_name}/error_level")


def run_rate():
    from RaTEScore import RaTEScore
    ratescore = RaTEScore()

    def met_fun(gt, me):
        return ratescore.compute_score([me], [gt])[0]

    run_all(met_fun, "rate")


def run_green():
    from green_score import GREEN

    model_name = "StanfordAIMI/GREEN-radllama2-7b"

    green_scorer = GREEN(model_name, output_dir=".")

    def met_fun(gt, me):
        mean, std, green_score_list, summary, result_df = green_scorer([gt], [me])
        return green_score_list[0]

    # try_met_fun(met_fun)

    run_all(met_fun, "green")


def run_bleu():
    import evaluate
    scorer = evaluate.load("bleu")

    def met_fun(gt, me):
        results = scorer.compute(predictions=[me], references=[[gt]])
        return results['bleu']

    # try_met_fun(met_fun)
    run_all(met_fun, "bleu")


def run_rouge():
    import evaluate
    scorer = evaluate.load("rouge")

    def met_fun(gt, me):
        results = scorer.compute(predictions=[me], references=[gt])
        return results['rougeL']

    # try_met_fun(met_fun)
    run_all(met_fun, "rouge-L")


def run_bert():
    import evaluate
    scorer = evaluate.load("bertscore")

    def met_fun(gt, me):
        results = scorer.compute(predictions=[me], references=[gt], model_type="distilbert-base-uncased")
        return results['f1'][0]

    # try_met_fun(met_fun)
    run_all(met_fun, "bert-f1")

def run_radfact():
    from radfact.metric.radfact import RadFactMetric

    radfact_metric_for_fg = RadFactMetric(is_narrative_text=True)

    def met_fun(gt, me):
        results_per_sample_fg = radfact_metric_for_fg.compute_results_per_sample({0: me}, {0: gt})
        print(results_per_sample_fg)
        score = results_per_sample_fg[0].scores.logical_f1
        return score

    # try_met_fun(met_fun)

    run_all(met_fun, "radfact")


def run_meteor():
    import evaluate
    scorer = evaluate.load("meteor")

    def met_fun(gt, me):
        results = scorer.compute(predictions=[me], references=[gt])
        return results['meteor']

    # try_met_fun(met_fun)
    run_all(met_fun, "meteor")


def run_align():
    from alignscore import AlignScore

    scorer = AlignScore(model='roberta-large', batch_size=32, device='cuda:0', ckpt_path='AlignScore-large.ckpt',
                        evaluation_mode='nli_sp')

    def met_fun(gt, me):
        score = scorer.score(contexts=[gt], claims=[me])
        return score[0]

    # try_met_fun(met_fun)
    run_all(met_fun, "align")


def run_radcliq():
    from CXRMetric.run_eval import compute_radcliq_v0_scores

    def met_fun(gt, me):
        score = compute_radcliq_v0_scores([gt], [me])
        return score[0]

    # try_met_fun(met_fun)
    run_all(met_fun, "radcliq_v0")


def run_radcliqv1():
    from CXRMetric.run_eval import compute_radcliq_v1_scores

    def met_fun(gt, me):
        score = compute_radcliq_v1_scores([gt], [me])
        return score[0]

    # try_met_fun(met_fun)
    run_all(met_fun, "radcliq_v1")


def run_CheXbert():
    from CXRMetric.run_eval import compute_semb_scores

    def met_fun(gt, me):
        score = compute_semb_scores([gt], [me])
        return score[0]

    # try_met_fun(met_fun)
    run_all(met_fun, "CheXbert")


def run_RadGraph():
    from CXRMetric.run_eval import compute_radgraph_scores

    def met_fun(gt, me):
        score = compute_radgraph_scores([gt], [me])
        return score[0]

    # try_met_fun(met_fun)
    run_all(met_fun, "RadGraph")


def run_bert2():
    from CXRMetric.run_eval import compute_bertscore_scores

    def met_fun(gt, me):
        score = compute_bertscore_scores([gt], [me])
        return score[0]

    try_met_fun(met_fun)
    # run_all(met_fun, "bert2")


def run_FineRad():
    from FineRadScore.gpt4_generations import generate_gpt4_response_zeroshot

    def met_fun(gt, me):
        score = generate_gpt4_response_zeroshot(me, gt)
        return score

    try_met_fun(met_fun)
    # run_all(met_fun, "FineRad")



def try_met_fun(met_fun):
    gt = "There are no pneumothoraces."
    me = "Pneumothorax is not definitely seen."
    score =  met_fun(gt, me)
    print("test score:", score)

def main():
    # run_rate()
    # run_green()
    # run_bleu()
    # run_rouge()
    # run_bert()
    # run_radfact()
    # run_meteor()
    # run_align()
    run_radcliq()
    run_radcliqv1()
    # run_CheXbert()
    # run_RadGraph()
    # run_bert2()
    # run_FineRad()

if __name__ == "__main__":
    main()
