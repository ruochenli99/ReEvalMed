import json
import numpy as np
import os
import re
import pandas as pd
import pickle
import torch
import sys

import tempfile
import shutil
from functools import lru_cache
from typing import List
from transformers import AutoTokenizer, AutoModel

from bert_score import BERTScorer
from fast_bleu import BLEU
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import MinMaxScaler

# import config
from CXRMetric.radgraph_evaluate_model import run_radgraph

"""Computes 4 individual metrics and a composite metric on radiology reports."""


CHEXBERT_PATH = "/media/data_sdh/billzhu/projects/ehr_metrics/CXRMetric/chexbert.pth"
RADGRAPH_PATH = "radgraph/physionet.org/files/radgraph/1.0.0/models/model_checkpoint/model.tar.gz"
RADGRAPH_PATH = "/media/data_sdh/billzhu/projects/ehr_metrics/model.tar.gz"

NORMALIZER_PATH = "CXRMetric/normalizer.pkl"
COMPOSITE_METRIC_V0_PATH = "CXRMetric/composite_metric_model.pkl"
COMPOSITE_METRIC_V1_PATH = "CXRMetric/radcliq-v1.pkl"

REPORT_COL_NAME = "report"
STUDY_ID_COL_NAME = "study_id"
COLS = ["radgraph_combined", "bertscore", "semb_score", "bleu_score"]

cache_path = "cache/"
pred_embed_path = os.path.join(cache_path, "pred_embeddings.pt")
gt_embed_path = os.path.join(cache_path, "gt_embeddings.pt")
weights = {"bigram": (1/2., 1/2.)}
#
# ----------------------------------------------------------------------
# Stand‑alone metric helpers (operate directly on lists of reports)
# ----------------------------------------------------------------------

@lru_cache(maxsize=1)
def _load_chexbert():
    """Load the CheXbert model/tokenizer once and cache them."""
    tokenizer = AutoTokenizer.from_pretrained(CHEXBERT_PATH)
    model = AutoModel.from_pretrained(CHEXBERT_PATH)
    model.eval()
    return tokenizer, model

def _embed_reports(reports: List[str]):
    """Return mean‑pooled CheXbert embeddings for a batch of reports."""
    import torch
    tokenizer, model = _load_chexbert()
    with torch.no_grad():
        encoded = tokenizer(
            reports,
            padding=True,
            truncation=True,
            return_tensors="pt"
        ).to(model.device)
        output = model(**encoded).last_hidden_state          # (B, T, H)
        mask = encoded["attention_mask"].unsqueeze(-1)       # (B, T, 1)
        summed = (output * mask).sum(dim=1)
        counts = mask.sum(dim=1)
        return (summed / counts).cpu()

# ---------- Individual metrics -------------------------------------------------

def compute_bleu_scores(gt_reports: List[str],
                        pred_reports: List[str]):
    """
    Compute BLEU‑2 score for each (gt, pred) pair.

    Returns:
        List[float]: BLEU‑2 scores, one per report pair.
    """
    assert len(gt_reports) == len(pred_reports), "gt/pred length mismatch"
    scores = []
    for gt, pred in zip(gt_reports, pred_reports):
        bleu = BLEU([prep_reports([gt])[0]], weights)
        score = bleu.get_score([prep_reports([pred])[0]])["bigram"][0]
        scores.append(score)
    return scores

def compute_bertscore_scores(gt_reports: List[str],
                             pred_reports: List[str],
                             use_idf: bool = False):
    """
    Compute BERTScore‑F1 for each report pair.

    Args:
        use_idf: Whether to use IDF re‑weighting (default: True).

    Returns:
        List[float]: BERTScore F1 per report pair.
    """
    assert len(gt_reports) == len(pred_reports), "gt/pred length mismatch"
    refs = [re.sub(r" +", " ", s) for s in gt_reports]
    hyps = [re.sub(r" +", " ", s) for s in pred_reports]
    scorer = BERTScorer(
        model_type="distilroberta-base",
        batch_size=256,
        lang="en",
        rescale_with_baseline=True,
        # idf=use_idf,
        # idf_sents=refs,
        num_layers=5,
    )
    _, _, f1 = scorer.score(hyps, refs)
    return f1.tolist()

def compute_semb_scores(gt_reports: List[str],
                        pred_reports: List[str]):
    """
    Compute s_emb cosine similarity for each (gt, pred) pair by invoking the
    canonical CheXbert embedder (`encode.py`) exactly as done in `calc_metric`.

    This guarantees that ad‑hoc evaluations here use *identical* embeddings to
    those written to disk during the full metric pipeline.

    Returns:
        List[float]: Cosine similarity scores, one per report pair.
    """
    import os, csv, tempfile, torch, shutil
    assert len(gt_reports) == len(pred_reports), "gt/pred length mismatch"

    # Create a temporary workspace mirroring `calc_metric`’s procedure
    tmp_dir = tempfile.mkdtemp()
    gt_csv   = os.path.join(tmp_dir, "gt.csv")
    pred_csv = os.path.join(tmp_dir, "pred.csv")
    gt_pt    = os.path.join(tmp_dir, "gt_embeddings.pt")
    pred_pt  = os.path.join(tmp_dir, "pred_embeddings.pt")

    # Write CSVs expected by encode.py
    with open(gt_csv, "w", newline="") as f_gt, \
         open(pred_csv, "w", newline="") as f_pred:
        writer_gt   = csv.writer(f_gt)
        writer_pred = csv.writer(f_pred)
        writer_gt.writerow([STUDY_ID_COL_NAME, REPORT_COL_NAME])
        writer_pred.writerow([STUDY_ID_COL_NAME, REPORT_COL_NAME])
        for idx, (gt, pr) in enumerate(zip(gt_reports, pred_reports)):
            writer_gt.writerow([idx, gt])
            writer_pred.writerow([idx, pr])

    # Run CheXbert encoder (same calls as in calc_metric)
    os.system(f"python CXRMetric/CheXbert/src/encode.py -c {CHEXBERT_PATH} "
              f"-d {gt_csv} -o {gt_pt}")
    os.system(f"python CXRMetric/CheXbert/src/encode.py -c {CHEXBERT_PATH} "
              f"-d {pred_csv} -o {pred_pt}")

    # Load embeddings and compute cosine similarity
    label_embeds = torch.load(gt_pt)
    pred_embeds  = torch.load(pred_pt)
    scores = []
    for idx in sorted(label_embeds.keys()):
        g = label_embeds[idx]
        p = pred_embeds[idx]
        sim = (g * p).sum() / (torch.norm(g) * torch.norm(p))
        scores.append(float(sim))

    # Clean‑up temp files
    shutil.rmtree(tmp_dir, ignore_errors=True)
    return scores

def compute_radgraph_scores(gt_reports: List[str],
                            pred_reports: List[str]):
    """
    Compute RadGraph combined F1 for each (gt, pred) pair using run_radgraph.

    Returns:
        List[float]: Combined (entity + relation) F1 scores.
    """
    assert len(gt_reports) == len(pred_reports), "gt/pred length mismatch"

    import csv, json, os

    tmp_dir = tempfile.mkdtemp()
    gt_csv = os.path.join(tmp_dir, "gt.csv")
    pred_csv = os.path.join(tmp_dir, "pred.csv")

    # Write temporary CSV files expected by run_radgraph
    with open(gt_csv, "w", newline="") as f_gt, \
         open(pred_csv, "w", newline="") as f_pred:
        writer_gt = csv.writer(f_gt)
        writer_pred = csv.writer(f_pred)
        writer_gt.writerow([STUDY_ID_COL_NAME, REPORT_COL_NAME])
        writer_pred.writerow([STUDY_ID_COL_NAME, REPORT_COL_NAME])
        for idx, (gt, pr) in enumerate(zip(gt_reports, pred_reports)):
            writer_gt.writerow([idx, gt])
            writer_pred.writerow([idx, pr])

    # Run RadGraph evaluation
    entities_path = os.path.join(tmp_dir, "entities.json")
    relations_path = os.path.join(tmp_dir, "relations.json")
    run_radgraph(gt_csv, pred_csv, tmp_dir, RADGRAPH_PATH,
                 entities_path, relations_path)

    # Parse results
    with open(entities_path, "r") as f_ent, open(relations_path, "r") as f_rel:
        ent_scores = json.load(f_ent)
        rel_scores = json.load(f_rel)

    scores = []
    for idx in range(len(gt_reports)):
        ent_f1 = float(ent_scores[str(idx)][0])
        rel_f1 = float(rel_scores[str(idx)][0])
        scores.append((ent_f1 + rel_f1) / 2.0)

    # Clean‑up
    shutil.rmtree(tmp_dir, ignore_errors=True)
    return scores

# ---------- Composite metrics --------------------------------------------------

def compute_radcliq_v0_scores(gt_reports: List[str],
                              pred_reports: List[str],
                              use_idf: bool = True):
    """
    Compute RadCliQ‑v0 composite metric for each pair.

    Returns:
        List[float]: RadCliQ‑v0 scores.
    """
    bleu  = compute_bleu_scores(gt_reports, pred_reports)
    bert  = compute_bertscore_scores(gt_reports, pred_reports, use_idf)
    semb  = compute_semb_scores(gt_reports, pred_reports)
    radg  = compute_radgraph_scores(gt_reports, pred_reports)

    with open(NORMALIZER_PATH, "rb") as f_norm, \
         open(COMPOSITE_METRIC_V0_PATH, "rb") as f_model:
        normalizer = pickle.load(f_norm)
        model      = pickle.load(f_model)

    X = np.stack([radg, bert, semb, bleu], axis=1)
    X_norm = normalizer.transform(X)
    return model.predict(X_norm).tolist()

def compute_radcliq_v1_scores(gt_reports: List[str],
                              pred_reports: List[str],
                              use_idf: bool = True):
    """
    Compute RadCliQ‑v1 composite metric for each pair.

    Returns:
        List[float]: RadCliQ‑v1 scores.
    """
    bleu  = compute_bleu_scores(gt_reports, pred_reports)
    bert  = compute_bertscore_scores(gt_reports, pred_reports, use_idf)
    semb  = compute_semb_scores(gt_reports, pred_reports)
    radg  = compute_radgraph_scores(gt_reports, pred_reports)

    with open(COMPOSITE_METRIC_V1_PATH, "rb") as f_model:
        model = pickle.load(f_model)

    X = np.stack([radg, bert, semb, bleu], axis=1)
    return model.predict(X).tolist()
composite_metric_col_v0 = "RadCliQ-v0"
composite_metric_col_v1 = "RadCliQ-v1"


class CompositeMetric:
    """The RadCliQ-v1 composite metric.

    Attributes:
        scaler: Input normalizer.
        coefs: Coefficients including the intercept.
    """
    def __init__(self, scaler, coefs):
        """Initializes the composite metric with a normalizer and coefficients.

        Args:
            scaler: Input normalizer.
            coefs: Coefficients including the intercept.
        """
        self.scaler = scaler
        self.coefs = coefs

    def predict(self, x):
        """Generates composite metric score for input.

        Args:
            x: Input data.

        Returns:
            Composite metric score.
        """
        norm_x = self.scaler.transform(x)
        norm_x = np.concatenate(
            (norm_x, np.ones((norm_x.shape[0], 1))), axis=1)
        pred = norm_x @ self.coefs
        return pred

sys.modules['__main__'].CompositeMetric = CompositeMetric


def prep_reports(reports):
    """Preprocesses reports"""
    return [list(filter(
        lambda val: val !=  "", str(elem)\
            .lower().replace(".", " .").split(" "))) for elem in reports]

def add_bleu_col(gt_df, pred_df):
    """Computes BLEU-2 and adds scores as a column to prediction df."""
    pred_df["bleu_score"] = [0.0] * len(pred_df)
    for i, row in gt_df.iterrows():
        gt_report = prep_reports([row[REPORT_COL_NAME]])[0]
        pred_row = pred_df[pred_df[STUDY_ID_COL_NAME] == row[STUDY_ID_COL_NAME]]
        predicted_report = \
            prep_reports([pred_row[REPORT_COL_NAME].values[0]])[0]
        if len(pred_row) == 1:
            bleu = BLEU([gt_report], weights)
            score = bleu.get_score([predicted_report])["bigram"]
            assert len(score) == 1
            _index = pred_df.index[
                pred_df[STUDY_ID_COL_NAME]==row[STUDY_ID_COL_NAME]].tolist()[0]
            pred_df.at[_index, "bleu_score"] = score[0]
    return pred_df

def add_bertscore_col(gt_df, pred_df, use_idf):
    """Computes BERTScore and adds scores as a column to prediction df."""
    test_reports = gt_df[REPORT_COL_NAME].tolist()
    test_reports = [re.sub(r' +', ' ', test) for test in test_reports]
    method_reports = pred_df[REPORT_COL_NAME].tolist()
    method_reports = [re.sub(r' +', ' ', report) for report in method_reports]

    scorer = BERTScorer(
        model_type="distilroberta-base",
        batch_size=256,
        lang="en",
        rescale_with_baseline=True,
        idf=use_idf,
        idf_sents=test_reports)
    _, _, f1 = scorer.score(method_reports, test_reports)
    pred_df["bertscore"] = f1
    return pred_df

def add_semb_col(pred_df, semb_path, gt_path):
    """Computes s_emb and adds scores as a column to prediction df."""
    label_embeds = torch.load(gt_path)
    pred_embeds = torch.load(semb_path)
    list_label_embeds = []
    list_pred_embeds = []
    for data_idx in sorted(label_embeds.keys()):
        list_label_embeds.append(label_embeds[data_idx])
        list_pred_embeds.append(pred_embeds[data_idx])
    np_label_embeds = torch.stack(list_label_embeds, dim=0).numpy()
    np_pred_embeds = torch.stack(list_pred_embeds, dim=0).numpy()
    scores = []
    for i, (label, pred) in enumerate(zip(np_label_embeds, np_pred_embeds)):
        sim_scores = (label * pred).sum() / (
            np.linalg.norm(label) * np.linalg.norm(pred))
        scores.append(sim_scores)
    pred_df["semb_score"] = scores
    return pred_df

def add_radgraph_col(pred_df, entities_path, relations_path):
    """Computes RadGraph F1 and adds scores as a column to prediction df."""
    study_id_to_radgraph = {}
    with open(entities_path, "r") as f:
        scores = json.load(f)
        for study_id, (f1, _, _) in scores.items():
            try:
                study_id_to_radgraph[int(study_id)] = float(f1)
            except:
                continue
    with open(relations_path, "r") as f:
        scores = json.load(f)
        for study_id, (f1, _, _) in scores.items():
            try:
                study_id_to_radgraph[int(study_id)] += float(f1)
                study_id_to_radgraph[int(study_id)] /= float(2)
            except:
                continue
    radgraph_scores = []
    count = 0
    for i, row in pred_df.iterrows():
        radgraph_scores.append(study_id_to_radgraph[int(row[STUDY_ID_COL_NAME])])
    pred_df["radgraph_combined"] = radgraph_scores
    return pred_df

def calc_metric(gt_csv, pred_csv, out_csv, use_idf): # TODO: support single metrics at a time
    """Computes four metrics and composite metric scores."""
    os.environ["MKL_THREADING_LAYER"] = "GNU"

    cache_gt_csv = os.path.join(
        os.path.dirname(gt_csv), f"cache_{os.path.basename(gt_csv)}")
    cache_pred_csv = os.path.join(
        os.path.dirname(pred_csv), f"cache_{os.path.basename(pred_csv)}")
    gt = pd.read_csv(gt_csv)\
        .sort_values(by=[STUDY_ID_COL_NAME]).reset_index(drop=True)
    pred = pd.read_csv(pred_csv)\
        .sort_values(by=[STUDY_ID_COL_NAME]).reset_index(drop=True)

    # Keep intersection of study IDs
    gt_study_ids = set(gt[STUDY_ID_COL_NAME])
    pred_study_ids = set(pred[STUDY_ID_COL_NAME])
    shared_study_ids = gt_study_ids.intersection(pred_study_ids)
    print(f"Number of shared study IDs: {len(shared_study_ids)}")
    gt = gt.loc[gt[STUDY_ID_COL_NAME].isin(shared_study_ids)].reset_index()
    pred = pred.loc[pred[STUDY_ID_COL_NAME].isin(shared_study_ids)].reset_index()

    gt.to_csv(cache_gt_csv)
    pred.to_csv(cache_pred_csv)

    # check that length and study IDs are the same
    assert len(gt) == len(pred)
    assert (REPORT_COL_NAME in gt.columns) and (REPORT_COL_NAME in pred.columns)
    assert (gt[STUDY_ID_COL_NAME].equals(pred[STUDY_ID_COL_NAME]))

    # add blue column to the eval df
    pred = add_bleu_col(gt, pred)

    # add bertscore column to the eval df
    pred = add_bertscore_col(gt, pred, use_idf)

    # run encode.py to make the semb column
    os.system(f"mkdir -p {cache_path}")
    os.system(f"python CXRMetric/CheXbert/src/encode.py -c {CHEXBERT_PATH} -d {cache_pred_csv} -o {pred_embed_path}")
    os.system(f"python CXRMetric/CheXbert/src/encode.py -c {CHEXBERT_PATH} -d {cache_gt_csv} -o {gt_embed_path}")
    pred = add_semb_col(pred, pred_embed_path, gt_embed_path)

    # run radgraph to create that column
    entities_path = os.path.join(cache_path, "entities_cache.json")
    relations_path = os.path.join(cache_path, "relations_cache.json")
    run_radgraph(cache_gt_csv, cache_pred_csv, cache_path, RADGRAPH_PATH,
                 entities_path, relations_path)
    pred = add_radgraph_col(pred, entities_path, relations_path)

    # compute composite metric: RadCliQ-v0
    with open(COMPOSITE_METRIC_V0_PATH, "rb") as f:
        composite_metric_v0_model = pickle.load(f)
    with open(NORMALIZER_PATH, "rb") as f:
        normalizer = pickle.load(f)
    # normalize
    input_data = np.array(pred[COLS])
    norm_input_data = normalizer.transform(input_data)
    # generate new col
    radcliq_v0_scores = composite_metric_v0_model.predict(norm_input_data)
    pred[composite_metric_col_v0] = radcliq_v0_scores

    # compute composite metric: RadCliQ-v1
    with open(COMPOSITE_METRIC_V1_PATH, "rb") as f:
        composite_metric_v1_model = pickle.load(f)
    input_data = np.array(pred[COLS])
    radcliq_v1_scores = composite_metric_v1_model.predict(input_data)
    pred[composite_metric_col_v1] = radcliq_v1_scores

    # save results in the out folder
    pred.to_csv(out_csv)
